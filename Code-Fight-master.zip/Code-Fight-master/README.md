# Code-Fight
Large companies with thousands of employees can evaluate and find out their best working employees and hence also the worst performing employees through this project. During company down-sizing, this project will be super useful and effective.
